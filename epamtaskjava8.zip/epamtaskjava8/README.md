# Nizam-Mohammed-Epam_PEP-Introduction_To_Java8features_And_Multi-Threading-Session_12
Epam PEP home task on Introduction to Java8 features and Multi-Threading session number 12

[Problem Statement](https://github.com/nizam19/Nizam-Mohammed-Epam_PEP-Introduction_To_Java8features_And_Multi-Threading-Session_11/blob/master/PEP-Java8-Task.pdf)

[Java Files](https://github.com/nizam19/Nizam-Mohammed-Epam_PEP-Introduction_To_Java8features_And_Multi-Threading-Session_11/tree/master/lambdas_streams/src/main/java/com/epam/lambdas_streams)
